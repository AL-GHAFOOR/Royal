﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using GHospital_Care.DAL.Gatway;

namespace GHospital_Care.BAL.Manager
{
    
     public class DoctorWisePatientManager
     {
         private DoctorWisePatientGatway aDoctorWisePatientGatway;

         public DataTable LoadDoctors()
         {
             DataTable data = new DataTable();
             aDoctorWisePatientGatway=new DoctorWisePatientGatway();
             data = aDoctorWisePatientGatway.LoadDoctors();
             return data;
         }
         public DataTable LoadRefferedInfo()
         {
             DataTable data = new DataTable();
             aDoctorWisePatientGatway = new DoctorWisePatientGatway();
             data = aDoctorWisePatientGatway.LoadRefferedInfo();
             return data;
         }
         public DataTable GridLoadRefferedBy(string RefferedBy)
         {
             DataTable data = new DataTable();
             aDoctorWisePatientGatway = new DoctorWisePatientGatway();
             data = aDoctorWisePatientGatway.GridLoadRefferedBy(RefferedBy);
             return data;
         }


         public DataTable GridLoadDutyDoctor(string Doctor)
         {
             DataTable data = new DataTable();
             aDoctorWisePatientGatway = new DoctorWisePatientGatway();
             data = aDoctorWisePatientGatway.GridLoadDutyDoctor(Doctor);
             return data;
         }
         public DataTable GridLoadDefault()
         {
             DataTable data = new DataTable();
             aDoctorWisePatientGatway = new DoctorWisePatientGatway();
             data = aDoctorWisePatientGatway.GridLoadDefault();
             return data;
         }
     }
}
