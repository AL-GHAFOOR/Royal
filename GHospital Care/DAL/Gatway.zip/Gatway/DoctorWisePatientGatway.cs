﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using GHospital_Care.DAL.Gateway;

namespace GHospital_Care.DAL.Gatway
{
    public class DoctorWisePatientGatway : GatwayConnection
    {
        public DataTable LoadDoctors()
        {
            Query = "SELECT * FROM tblDoctors";
            Command = new SqlCommand(Query, Connection);
            Command.CommandText = Query;
            Reader = Command.ExecuteReader();
            DataTable data = new DataTable();
            data.Load(Reader);
            return data;
        }

        public DataTable LoadRefferedInfo()
        {
            Query = "SELECT * FROM RefferedInfo";
            Command = new SqlCommand(Query, Connection);
            Command.CommandText = Query;
            Reader = Command.ExecuteReader();
            DataTable data = new DataTable();
            data.Load(Reader);
            return data;
        }

        public DataTable GridLoadDutyDoctor(string Doctor)
        {
            Query = "SELECT * FROM tbl_IndoorAdmission WHERE DutyDoctorId='" + Doctor + "'";
            Command = new SqlCommand(Query, Connection);
            Command.CommandText = Query;
            Reader = Command.ExecuteReader();
            DataTable data = new DataTable();
            data.Load(Reader);
            return data;
        }

        public DataTable GridLoadRefferedBy(string RefferedBy)
        {
            Query = "SELECT * FROM ViewPatientByDoctorReffered WHERE RefferedBy='" + RefferedBy + "'";
            Command = new SqlCommand(Query, Connection);
            Command.CommandText = Query;
            Reader = Command.ExecuteReader();
            DataTable data = new DataTable();
            data.Load(Reader);
            return data;
        }



        public DataTable GridLoadDefault()
        {
            Query = "SELECT * FROM ViewPatientByDoctorReffered";
            Command = new SqlCommand(Query, Connection);
            Command.CommandText = Query;
            Reader = Command.ExecuteReader();
            DataTable data = new DataTable();
            data.Load(Reader);
            return data;
        }

    }
}
