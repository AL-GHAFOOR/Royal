﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GHospital_Care.DAL.Gatway
{
    class OpInformationGatway
    {

    }
}
