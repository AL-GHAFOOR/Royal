﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using GHospital_Care.DAL.Model;

namespace GHospital_Care.DAL.Gateway
{
    class FollowUPGateway : GatwayConnection
    {

        public DataTable LoadFollowUpSubItem()
        {
            Query = "Select * from viewAllFollupItemWithSubItem ";
            Command = new SqlCommand(Query, Connection);
            Command.CommandText = Query;
            Reader = Command.ExecuteReader();
            DataTable data = new DataTable();
            data.Load(Reader);
            return data;
        }

        public int InsertFollowupSheet(List<FollowUPMaster> FollowUp)
        {
            int count = 0;
            foreach (FollowUPMaster master in FollowUp)
            {
                Query = "Insert into tblFollowUpSheetMaster (DeptId,FollowupId) values(@DeptId,@FollowupId)";
                Command = new SqlCommand(Query, Connection);
                // Command.CommandType = CommandType.Text;
                Command.Parameters.AddWithValue("@DeptId", Convert.ToInt16(master.DepartmentId));
                Command.Parameters.AddWithValue("@FollowupId", Convert.ToInt16(master.ID));
                count += Command.ExecuteNonQuery();

                foreach (FollowUpSubItem VARIABLE in master.SubItems)
                {
                    Query = "Insert into tblFollowUpSheetDetails (FollowSheetMasterId,FollowSheetDetailsID,Department) values(@FollowSheetMasterId,@FollowSheetDetailsID,@Department)";
                    // Command.CommandType = CommandType.Text;
                    Command = new SqlCommand(Query, Connection);
                    Command.Parameters.AddWithValue("@FollowSheetMasterId", Convert.ToInt16(master.ID));
                    Command.Parameters.AddWithValue("@FollowSheetDetailsID", Convert.ToInt16(VARIABLE.Id));
                    Command.Parameters.AddWithValue("@Department", Convert.ToInt16(master.DepartmentId)); count += Command.ExecuteNonQuery();


                }
            }
            return count;
        }
        public DataTable FollowMaster()
        {
            Query = "Select * from tblFollowUp ";
            Command = new SqlCommand(Query, Connection);
            Command.CommandText = Query;
            Reader = Command.ExecuteReader();
            DataTable data = new DataTable();
            data.Load(Reader);
            return data;
        }
        public DataTable LoadTreatmentDepartment()
        {
            Query = "Select * from tblDeparment_Treatment ";
            Command = new SqlCommand(Query, Connection);
            Command.CommandText = Query;
            Reader = Command.ExecuteReader();
            DataTable data = new DataTable();
            data.Load(Reader);
            return data;
        }
        public int SaveFollowUPSetup(FollowUPMaster followUp)
        {
            int count = 0;

            Command = new SqlCommand("INSERT INTO dbo.tblFollowUp (FollowUpItemName,Description,DepartmentID,Rate)"
                  + "VALUES(@FollowUpItemName,@Description,@DepartmentID,@Rate)", Connection);

            Command.CommandType = CommandType.Text;
            Command.Parameters.AddWithValue("@FollowUpItemName", followUp.FollowUpItemName);
            Command.Parameters.AddWithValue("@Description", followUp.Description);
            Command.Parameters.AddWithValue("@DepartmentID", "");
            Command.Parameters.AddWithValue("@Rate", followUp.Rate);


            count = Command.ExecuteNonQuery();

            foreach (FollowUpSubItem subItem in followUp.SubItems)
            {
                Command = new SqlCommand("INSERT INTO dbo.tblFollowSubItems (ItemID,SubItemName)"
                 + "VALUES(@ItemID,@SubItemName)", Connection);

                Command.CommandType = CommandType.Text;
                Command.Parameters.AddWithValue("@ItemID", followUp.ID);
                Command.Parameters.AddWithValue("@SubItemName", subItem.SubItemName);
                count = Command.ExecuteNonQuery();
            }






            return count;
        }
    }
}
